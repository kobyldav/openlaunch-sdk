"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CelesTrakClient = void 0;
exports.ommToOrbitalElements = ommToOrbitalElements;
exports.ommToApproximateState = ommToApproximateState;
const cache_js_1 = require("../cache.js");
const http_js_1 = require("../http.js");
function queryToParams(query, defaultFormat = "JSON") {
    const out = { FORMAT: query.format ?? defaultFormat };
    if (query.catnr !== undefined)
        out.CATNR = query.catnr;
    if (query.intdes)
        out.INTDES = query.intdes;
    if (query.group)
        out.GROUP = query.group;
    if (query.name)
        out.NAME = query.name;
    if (query.special)
        out.SPECIAL = query.special;
    return out;
}
class CelesTrakClient {
    http;
    constructor(options = {}) {
        const fetchImpl = options.fetch ?? globalThis.fetch;
        if (!fetchImpl)
            throw new Error("No fetch implementation available");
        const cache = options.cache === false ? undefined : options.cache ?? new cache_js_1.MemoryCache(200);
        this.http = new http_js_1.HttpClient({ baseUrl: "https://celestrak.org/NORAD/elements/", fetchImpl, ...(cache ? { cache } : {}), cacheTtlMs: options.cacheTtlMs ?? 30 * 60_000, retries: 2, retryDelayMs: 750, timeoutMs: options.timeoutMs ?? 30_000, headers: {}, maxConcurrency: 2, minRequestIntervalMs: 250, deduplicate: true, circuitBreaker: { failureThreshold: 4, cooldownMs: 30_000 }, ...(options.onTelemetry ? { onTelemetry: options.onTelemetry } : {}) });
    }
    gp(query) { return this.http.get("gp.php", queryToParams(query)); }
    first(query) { return this.http.get("gp-first.php", queryToParams(query)); }
    byCatalogNumber(catnr) { return this.gp({ catnr }); }
    byInternationalDesignator(intdes) { return this.gp({ intdes }); }
    byGroup(group) { return this.gp({ group }); }
    byName(name) { return this.gp({ name }); }
    special(special) { return this.gp({ special }); }
    stations() { return this.byGroup("STATIONS"); }
    active() { return this.byGroup("ACTIVE"); }
    starlink() { return this.byGroup("STARLINK"); }
    gpsOperational() { return this.byGroup("GPS-OPS"); }
    galileo() { return this.byGroup("GALILEO"); }
    geoActive() { return this.byGroup("GEO"); }
    cubesats() { return this.byGroup("CUBESAT"); }
    weather() { return this.byGroup("WEATHER"); }
    science() { return this.byGroup("SCIENCE"); }
    async text(query, format = "TLE") { return this.http.get("gp.php", queryToParams({ ...query, format }, format), {}, { bypassCache: false }); }
    async supplemental(query) {
        const q = queryToParams(query);
        if (query.source)
            q.SOURCE = query.source;
        if (query.file)
            q.FILE = query.file;
        return this.http.get("supplemental/sup-gp.php", q);
    }
}
exports.CelesTrakClient = CelesTrakClient;
const constants_js_1 = require("../science/constants.js");
const orbits_js_1 = require("../science/orbits.js");
const units_js_1 = require("../science/units.js");
/** Convert a CelesTrak OMM mean-element record to a two-body element set. This is NOT SGP4 propagation. */
function ommToOrbitalElements(record, mu = constants_js_1.BODIES.earth.mu) {
    const meanMotionRevDay = Number(record.MEAN_MOTION);
    const eccentricity = Number(record.ECCENTRICITY);
    const inclinationRad = (0, units_js_1.toRadians)(Number(record.INCLINATION));
    const raanRad = (0, units_js_1.toRadians)(Number(record.RA_OF_ASC_NODE));
    const argumentOfPeriapsisRad = (0, units_js_1.toRadians)(Number(record.ARG_OF_PERICENTER));
    const meanAnomalyRad = (0, units_js_1.toRadians)(Number(record.MEAN_ANOMALY));
    if (![meanMotionRevDay, eccentricity, inclinationRad, raanRad, argumentOfPeriapsisRad, meanAnomalyRad].every(Number.isFinite))
        throw new Error("OMM record is missing required mean elements");
    const n = meanMotionRevDay * 2 * Math.PI / 86400;
    const semiMajorAxisM = (mu / (n * n)) ** (1 / 3);
    const eccentricAnomaly = (0, orbits_js_1.solveKepler)(meanAnomalyRad, eccentricity);
    const trueAnomalyRad = (0, orbits_js_1.trueAnomalyFromEccentric)(eccentricAnomaly, eccentricity);
    const semiLatusRectumM = semiMajorAxisM * (1 - eccentricity ** 2);
    const specificAngularMomentum = Math.sqrt(mu * semiLatusRectumM);
    return { semiMajorAxisM, eccentricity, inclinationRad, raanRad, argumentOfPeriapsisRad, trueAnomalyRad, semiLatusRectumM, specificAngularMomentum, specificOrbitalEnergy: -mu / (2 * semiMajorAxisM) };
}
/** Approximate state vector from OMM using Keplerian elements only. For operational satellite tracking use a validated SGP4 implementation. */
function ommToApproximateState(record, mu = constants_js_1.BODIES.earth.mu) { return (0, orbits_js_1.orbitalElementsToState)(ommToOrbitalElements(record, mu), mu); }
//# sourceMappingURL=celestrak.js.map