"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NasaClient = void 0;
const cache_js_1 = require("../cache.js");
const http_js_1 = require("../http.js");
class NasaClient {
    http;
    scienceHttp;
    apiKey;
    constructor(options = {}) {
        const fetchImpl = options.fetch ?? globalThis.fetch;
        if (!fetchImpl)
            throw new Error("No fetch implementation available");
        this.apiKey = options.apiKey ?? "DEMO_KEY";
        const cache = options.cache === false ? undefined : options.cache ?? new cache_js_1.MemoryCache(500);
        const common = { fetchImpl, ...(cache ? { cache } : {}), cacheTtlMs: options.cacheTtlMs ?? 10 * 60_000, retries: 2, retryDelayMs: 500, timeoutMs: options.timeoutMs ?? 30_000, headers: {}, maxConcurrency: 4, deduplicate: true, circuitBreaker: { failureThreshold: 5, cooldownMs: 30_000 }, ...(options.onTelemetry ? { onTelemetry: options.onTelemetry } : {}) };
        this.http = new http_js_1.HttpClient({ baseUrl: "https://api.nasa.gov/", ...common });
        this.scienceHttp = new http_js_1.HttpClient({ baseUrl: "https://science.nasa.gov/wp-json/wp/v2/", ...common });
    }
    raw(path, query = {}) { return this.http.get(path, { ...query, api_key: query.api_key ?? this.apiKey }); }
    neoFeed(startDate, endDate) { return this.raw("neo/rest/v1/feed", { start_date: startDate, end_date: endDate }); }
    neoLookup(id) { return this.raw(`neo/rest/v1/neo/${encodeURIComponent(String(id))}`); }
    neoBrowse(page = 0, size = 20) { return this.raw("neo/rest/v1/neo/browse", { page, size }); }
    donki(type, startDate, endDate) { return this.raw(`DONKI/${type}`, { startDate, endDate }); }
    epicNatural(date) { return this.raw(date ? `EPIC/api/natural/date/${date}` : "EPIC/api/natural"); }
    epicEnhanced(date) { return this.raw(date ? `EPIC/api/enhanced/date/${date}` : "EPIC/api/enhanced"); }
    techTransfer(query) { return this.raw("techtransfer/patent/", { q: query }); }
    apodCurrent(query = {}) { return this.scienceHttp.get("apod-basic", query); }
}
exports.NasaClient = NasaClient;
//# sourceMappingURL=nasa.js.map