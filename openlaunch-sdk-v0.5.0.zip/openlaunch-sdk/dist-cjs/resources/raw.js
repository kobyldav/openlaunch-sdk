"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigResource = exports.RawResource = void 0;
const utils_js_1 = require("../utils.js");
class RawResource {
    http;
    endpoint;
    constructor(http, endpoint) {
        this.http = http;
        this.endpoint = endpoint;
    }
    async list(options = {}) {
        const query = {
            limit: (0, utils_js_1.clampLimit)(options.limit), offset: options.offset, search: options.search,
            ordering: options.ordering, mode: options.mode, ...(options.filters ?? {}),
        };
        return this.http.get(`${this.endpoint}/`, query);
    }
    async get(id, mode = "detailed") {
        return this.http.get(`${this.endpoint}/${encodeURIComponent(String(id))}/`, { mode });
    }
    async *iterate(options = {}) {
        const maxItems = options.maxItems ?? Number.POSITIVE_INFINITY;
        const pageSize = (0, utils_js_1.clampLimit)(options.pageSize ?? options.limit ?? 100) ?? 100;
        let offset = options.offset ?? 0;
        let emitted = 0;
        while (emitted < maxItems) {
            const page = await this.list({ ...options, limit: pageSize, offset });
            for (const item of page.results) {
                yield item;
                emitted++;
                if (emitted >= maxItems)
                    return;
            }
            if (!page.next || page.results.length === 0)
                return;
            offset += page.results.length;
        }
    }
    async all(options = {}) {
        const result = [];
        for await (const item of this.iterate(options))
            result.push(item);
        return result;
    }
    async count(options = {}) {
        const page = await this.list({ ...options, limit: 1, offset: 0 });
        return page.count;
    }
    async action(suffix, query = {}) {
        return this.http.get(`${this.endpoint}/${suffix.replace(/^\//, "")}`, query);
    }
}
exports.RawResource = RawResource;
class ConfigResource {
    http;
    endpoint;
    constructor(http, endpoint) {
        this.http = http;
        this.endpoint = endpoint;
    }
    async list() {
        const raw = await this.http.get(`${this.endpoint}/`);
        if (Array.isArray(raw))
            return raw;
        if ((0, utils_js_1.isRecord)(raw) && Array.isArray(raw.results))
            return raw.results;
        return [];
    }
}
exports.ConfigResource = ConfigResource;
//# sourceMappingURL=raw.js.map