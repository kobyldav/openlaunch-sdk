"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.query = exports.QueryBuilder = void 0;
/** Fluent builder for LL2/Django-style filters. It deliberately preserves raw filter names so new API filters work without SDK releases. */
class QueryBuilder {
    value = {};
    eq(field, value) { this.value[field] = value; return this; }
    gt(field, value) { this.value[`${field}__gt`] = value; return this; }
    gte(field, value) { this.value[`${field}__gte`] = value; return this; }
    lt(field, value) { this.value[`${field}__lt`] = value; return this; }
    lte(field, value) { this.value[`${field}__lte`] = value; return this; }
    contains(field, value) { this.value[`${field}__contains`] = value; return this; }
    icontains(field, value) { this.value[`${field}__icontains`] = value; return this; }
    ids(field, values) { this.value[`${field}__ids`] = values; return this; }
    dateGte(field, value) { this.value[`${field}__gte`] = value.toISOString(); return this; }
    dateLte(field, value) { this.value[`${field}__lte`] = value.toISOString(); return this; }
    search(text) { this.value.search = text; return this; }
    ordering(...fields) { this.value.ordering = fields.join(","); return this; }
    limit(value) { this.value.limit = value; return this; }
    offset(value) { this.value.offset = value; return this; }
    mode(value) { this.value.mode = value; return this; }
    set(field, value) { this.value[field] = value; return this; }
    merge(query) { Object.assign(this.value, query); return this; }
    build() { return { ...this.value }; }
}
exports.QueryBuilder = QueryBuilder;
const query = () => new QueryBuilder();
exports.query = query;
//# sourceMappingURL=query.js.map