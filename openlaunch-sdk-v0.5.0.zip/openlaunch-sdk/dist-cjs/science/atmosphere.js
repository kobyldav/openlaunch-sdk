"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reynoldsNumber = exports.stagnationTemperature = exports.terminalVelocity = exports.ballisticCoefficient = exports.dragForce = exports.machNumber = exports.dynamicPressure = void 0;
exports.isa1976 = isa1976;
exports.sutherlandViscosity = sutherlandViscosity;
const constants_js_1 = require("./constants.js");
const GAMMA = 1.4, R_AIR = 287.05287;
function isa1976(altitudeM) {
    const h = Math.max(-500, Math.min(84_852, altitudeM));
    const layers = [
        { h0: 0, t0: 288.15, p0: 101325, lapse: -0.0065 },
        { h0: 11000, t0: 216.65, p0: 22632.06, lapse: 0 },
        { h0: 20000, t0: 216.65, p0: 5474.889, lapse: 0.001 },
        { h0: 32000, t0: 228.65, p0: 868.0187, lapse: 0.0028 },
        { h0: 47000, t0: 270.65, p0: 110.9063, lapse: 0 },
        { h0: 51000, t0: 270.65, p0: 66.93887, lapse: -0.0028 },
        { h0: 71000, t0: 214.65, p0: 3.956420, lapse: -0.002 },
    ];
    let layer = layers[0];
    for (const candidate of layers)
        if (h >= candidate.h0)
            layer = candidate;
    const dh = h - layer.h0;
    const temperatureK = layer.t0 + layer.lapse * dh;
    const pressurePa = layer.lapse === 0
        ? layer.p0 * Math.exp(-constants_js_1.PHYSICS.standardGravity * dh / (R_AIR * layer.t0))
        : layer.p0 * (temperatureK / layer.t0) ** (-constants_js_1.PHYSICS.standardGravity / (layer.lapse * R_AIR));
    const densityKgM3 = pressurePa / (R_AIR * temperatureK);
    return { temperatureK, pressurePa, densityKgM3, speedOfSoundMps: Math.sqrt(GAMMA * R_AIR * temperatureK) };
}
const dynamicPressure = (densityKgM3, velocityMps) => 0.5 * densityKgM3 * velocityMps ** 2;
exports.dynamicPressure = dynamicPressure;
const machNumber = (velocityMps, speedOfSoundMps) => velocityMps / speedOfSoundMps;
exports.machNumber = machNumber;
const dragForce = (densityKgM3, velocityMps, dragCoefficient, areaM2) => (0, exports.dynamicPressure)(densityKgM3, velocityMps) * dragCoefficient * areaM2;
exports.dragForce = dragForce;
const ballisticCoefficient = (massKg, dragCoefficient, areaM2) => massKg / (dragCoefficient * areaM2);
exports.ballisticCoefficient = ballisticCoefficient;
const terminalVelocity = (massKg, gravityMps2, densityKgM3, dragCoefficient, areaM2) => Math.sqrt(2 * massKg * gravityMps2 / (densityKgM3 * dragCoefficient * areaM2));
exports.terminalVelocity = terminalVelocity;
const stagnationTemperature = (staticTemperatureK, mach, gamma = 1.4) => staticTemperatureK * (1 + (gamma - 1) * mach * mach / 2);
exports.stagnationTemperature = stagnationTemperature;
const reynoldsNumber = (densityKgM3, velocityMps, lengthM, dynamicViscosityPaS) => densityKgM3 * velocityMps * lengthM / dynamicViscosityPaS;
exports.reynoldsNumber = reynoldsNumber;
function sutherlandViscosity(temperatureK) { const mu0 = 1.716e-5, t0 = 273.15, s = 110.4; return mu0 * (temperatureK / t0) ** 1.5 * (t0 + s) / (temperatureK + s); }
//# sourceMappingURL=atmosphere.js.map