"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.temperatureChangeFromEnergy = exports.heatCapacityEnergy = exports.absorbedSolarPower = exports.conductiveHeatFlow = exports.solarFluxAtDistance = exports.radiativeEquilibriumTemperature = exports.blackbodyRadiativePower = void 0;
const constants_js_1 = require("./constants.js");
const blackbodyRadiativePower = (areaM2, temperatureK, emissivity = 1) => emissivity * constants_js_1.PHYSICS.stefanBoltzmann * areaM2 * temperatureK ** 4;
exports.blackbodyRadiativePower = blackbodyRadiativePower;
const radiativeEquilibriumTemperature = (absorbedFluxWm2, absorptivity = 1, emissivity = 1, viewFactor = 4) => (absorptivity * absorbedFluxWm2 / (emissivity * constants_js_1.PHYSICS.stefanBoltzmann * viewFactor)) ** 0.25;
exports.radiativeEquilibriumTemperature = radiativeEquilibriumTemperature;
const solarFluxAtDistance = (distanceM) => constants_js_1.PHYSICS.solarConstant1AU * (constants_js_1.PHYSICS.astronomicalUnit / distanceM) ** 2;
exports.solarFluxAtDistance = solarFluxAtDistance;
const conductiveHeatFlow = (thermalConductivityWmK, areaM2, deltaTemperatureK, thicknessM) => thermalConductivityWmK * areaM2 * deltaTemperatureK / thicknessM;
exports.conductiveHeatFlow = conductiveHeatFlow;
const absorbedSolarPower = (fluxWm2, areaM2, absorptivity = 1, incidenceAngleRad = 0) => fluxWm2 * areaM2 * absorptivity * Math.max(0, Math.cos(incidenceAngleRad));
exports.absorbedSolarPower = absorbedSolarPower;
const heatCapacityEnergy = (massKg, specificHeatJkgK, deltaTemperatureK) => massKg * specificHeatJkgK * deltaTemperatureK;
exports.heatCapacityEnergy = heatCapacityEnergy;
const temperatureChangeFromEnergy = (energyJ, massKg, specificHeatJkgK) => energyJ / (massKg * specificHeatJkgK);
exports.temperatureChangeFromEnergy = temperatureChangeFromEnergy;
//# sourceMappingURL=thermal.js.map