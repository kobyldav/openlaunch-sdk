"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.J2000_JULIAN_DATE = void 0;
exports.toJulianDate = toJulianDate;
exports.fromJulianDate = fromJulianDate;
exports.julianCenturiesSinceJ2000 = julianCenturiesSinceJ2000;
exports.gmstDegrees = gmstDegrees;
exports.gmstRadians = gmstRadians;
exports.localSiderealDegrees = localSiderealDegrees;
exports.dayOfYear = dayOfYear;
exports.addSeconds = addSeconds;
exports.secondsBetween = secondsBetween;
exports.unixSeconds = unixSeconds;
exports.fromUnixSeconds = fromUnixSeconds;
exports.durationParts = durationParts;
const units_js_1 = require("./units.js");
exports.J2000_JULIAN_DATE = 2451545.0;
function toJulianDate(date) { return date.getTime() / 86_400_000 + 2440587.5; }
function fromJulianDate(jd) { return new Date((jd - 2440587.5) * 86_400_000); }
function julianCenturiesSinceJ2000(date) { return (toJulianDate(date) - exports.J2000_JULIAN_DATE) / 36525; }
function gmstDegrees(date) {
    const jd = toJulianDate(date);
    const t = (jd - 2451545.0) / 36525.0;
    return (0, units_js_1.normalizeDegrees)(280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * t * t - t * t * t / 38710000);
}
function gmstRadians(date) { return gmstDegrees(date) * Math.PI / 180; }
function localSiderealDegrees(date, longitudeDegrees) { return (0, units_js_1.normalizeDegrees)(gmstDegrees(date) + longitudeDegrees); }
function dayOfYear(date) {
    const start = Date.UTC(date.getUTCFullYear(), 0, 1);
    return Math.floor((date.getTime() - start) / 86_400_000) + 1;
}
function addSeconds(date, seconds) { return new Date(date.getTime() + seconds * 1000); }
function secondsBetween(a, b) { return (b.getTime() - a.getTime()) / 1000; }
function unixSeconds(date) { return date.getTime() / 1000; }
function fromUnixSeconds(seconds) { return new Date(seconds * 1000); }
function durationParts(totalSeconds) {
    let s = Math.floor(Math.abs(totalSeconds));
    const days = Math.floor(s / 86400);
    s %= 86400;
    const hours = Math.floor(s / 3600);
    s %= 3600;
    const minutes = Math.floor(s / 60);
    s %= 60;
    return { days, hours, minutes, seconds: s };
}
//# sourceMappingURL=time.js.map