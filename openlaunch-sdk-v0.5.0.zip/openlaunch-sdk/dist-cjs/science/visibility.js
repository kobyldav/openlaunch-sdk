"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hasLineOfSight = hasLineOfSight;
exports.inCylindricalEclipse = inCylindricalEclipse;
exports.angularSeparationRad = angularSeparationRad;
exports.occultedBySphere = occultedBySphere;
const vector_js_1 = require("./vector.js");
/** True when the line segment between two positions does not intersect a spherical body. */
function hasLineOfSight(a, b, bodyRadiusM) {
    const d = (0, vector_js_1.sub3)(b, a);
    const dd = (0, vector_js_1.dot3)(d, d);
    if (dd === 0)
        return (0, vector_js_1.norm3)(a) > bodyRadiusM;
    const t = Math.max(0, Math.min(1, -(0, vector_js_1.dot3)(a, d) / dd));
    const closest = [a[0] + d[0] * t, a[1] + d[1] * t, a[2] + d[2] * t];
    return (0, vector_js_1.norm3)(closest) > bodyRadiusM;
}
/** Cylindrical-shadow eclipse approximation: spacecraft is behind the occulting body relative to the Sun and inside its projected radius. */
function inCylindricalEclipse(spacecraftFromBody, sunFromBody, bodyRadiusM) {
    const sunDistance = (0, vector_js_1.norm3)(sunFromBody);
    if (sunDistance === 0)
        return false;
    const sunHat = (0, vector_js_1.scale3)(sunFromBody, 1 / sunDistance);
    const axial = (0, vector_js_1.dot3)(spacecraftFromBody, sunHat);
    if (axial >= 0)
        return false;
    const perpendicular = (0, vector_js_1.sub3)(spacecraftFromBody, (0, vector_js_1.scale3)(sunHat, axial));
    return (0, vector_js_1.norm3)(perpendicular) < bodyRadiusM;
}
function angularSeparationRad(a, b) {
    const denom = (0, vector_js_1.norm3)(a) * (0, vector_js_1.norm3)(b);
    return denom === 0 ? 0 : Math.acos(Math.max(-1, Math.min(1, (0, vector_js_1.dot3)(a, b) / denom)));
}
function occultedBySphere(observer, target, bodyCenter, bodyRadiusM) {
    return !hasLineOfSight((0, vector_js_1.sub3)(observer, bodyCenter), (0, vector_js_1.sub3)(target, bodyCenter), bodyRadiusM);
}
//# sourceMappingURL=visibility.js.map