"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WGS84 = void 0;
exports.geodeticToEcef = geodeticToEcef;
exports.ecefToGeodetic = ecefToGeodetic;
exports.haversineDistanceM = haversineDistanceM;
exports.initialBearingDeg = initialBearingDeg;
exports.destinationPoint = destinationPoint;
exports.horizonDistanceM = horizonDistanceM;
exports.eciToEcef = eciToEcef;
exports.ecefToEci = ecefToEci;
exports.earthRotationSurfaceSpeed = earthRotationSurfaceSpeed;
exports.lookAngles = lookAngles;
exports.relativeEcef = relativeEcef;
exports.midpointEcef = midpointEcef;
const constants_js_1 = require("./constants.js");
const vector_js_1 = require("./vector.js");
const time_js_1 = require("./time.js");
const units_js_1 = require("./units.js");
exports.WGS84 = Object.freeze({ a: 6_378_137, f: 1 / 298.257223563, b: 6_356_752.314245, e2: 6.69437999014e-3 });
function geodeticToEcef(position) {
    const lat = (0, units_js_1.toRadians)(position.latitudeDeg), lon = (0, units_js_1.toRadians)(position.longitudeDeg);
    const sinLat = Math.sin(lat), cosLat = Math.cos(lat);
    const n = exports.WGS84.a / Math.sqrt(1 - exports.WGS84.e2 * sinLat * sinLat);
    const x = (n + position.altitudeM) * cosLat * Math.cos(lon);
    const y = (n + position.altitudeM) * cosLat * Math.sin(lon);
    const z = (n * (1 - exports.WGS84.e2) + position.altitudeM) * sinLat;
    return [x, y, z];
}
function ecefToGeodetic(ecef) {
    const [x, y, z] = ecef;
    const lon = Math.atan2(y, x);
    const p = Math.hypot(x, y);
    let lat = Math.atan2(z, p * (1 - exports.WGS84.e2));
    let alt = 0;
    for (let i = 0; i < 10; i++) {
        const sinLat = Math.sin(lat);
        const n = exports.WGS84.a / Math.sqrt(1 - exports.WGS84.e2 * sinLat * sinLat);
        alt = p / Math.max(1e-12, Math.cos(lat)) - n;
        const next = Math.atan2(z, p * (1 - exports.WGS84.e2 * n / (n + alt)));
        if (Math.abs(next - lat) < 1e-12) {
            lat = next;
            break;
        }
        lat = next;
    }
    return { latitudeDeg: (0, units_js_1.toDegrees)(lat), longitudeDeg: (0, units_js_1.toDegrees)(lon), altitudeM: alt };
}
function haversineDistanceM(a, b, radiusM = exports.WGS84.a) {
    const p1 = (0, units_js_1.toRadians)(a.latitudeDeg), p2 = (0, units_js_1.toRadians)(b.latitudeDeg);
    const dp = p2 - p1, dl = (0, units_js_1.toRadians)(b.longitudeDeg - a.longitudeDeg);
    const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
    return 2 * radiusM * Math.asin(Math.min(1, Math.sqrt(h)));
}
function initialBearingDeg(a, b) {
    const p1 = (0, units_js_1.toRadians)(a.latitudeDeg), p2 = (0, units_js_1.toRadians)(b.latitudeDeg), dl = (0, units_js_1.toRadians)(b.longitudeDeg - a.longitudeDeg);
    const y = Math.sin(dl) * Math.cos(p2), x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
    return ((0, units_js_1.toDegrees)(Math.atan2(y, x)) + 360) % 360;
}
function destinationPoint(origin, bearingDeg, distanceM, radiusM = exports.WGS84.a) {
    const p1 = (0, units_js_1.toRadians)(origin.latitudeDeg), l1 = (0, units_js_1.toRadians)(origin.longitudeDeg), br = (0, units_js_1.toRadians)(bearingDeg), d = distanceM / radiusM;
    const p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(br));
    const l2 = l1 + Math.atan2(Math.sin(br) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2));
    return { latitudeDeg: (0, units_js_1.toDegrees)(p2), longitudeDeg: (((0, units_js_1.toDegrees)(l2) + 540) % 360) - 180, altitudeM: 0 };
}
function horizonDistanceM(altitudeM, radiusM = exports.WGS84.a) { return Math.sqrt(Math.max(0, 2 * radiusM * altitudeM + altitudeM * altitudeM)); }
function eciToEcef(eci, date) { return (0, vector_js_1.rotateZ3)(eci, -(0, time_js_1.gmstRadians)(date)); }
function ecefToEci(ecef, date) { return (0, vector_js_1.rotateZ3)(ecef, (0, time_js_1.gmstRadians)(date)); }
function earthRotationSurfaceSpeed(latitudeDeg) { return constants_js_1.PHYSICS.earthRotationRate * exports.WGS84.a * Math.cos((0, units_js_1.toRadians)(latitudeDeg)); }
function lookAngles(observer, targetEcef) {
    const obs = geodeticToEcef(observer);
    const d = (0, vector_js_1.sub3)(targetEcef, obs);
    const lat = (0, units_js_1.toRadians)(observer.latitudeDeg), lon = (0, units_js_1.toRadians)(observer.longitudeDeg);
    const east = -Math.sin(lon) * d[0] + Math.cos(lon) * d[1];
    const north = -Math.sin(lat) * Math.cos(lon) * d[0] - Math.sin(lat) * Math.sin(lon) * d[1] + Math.cos(lat) * d[2];
    const up = Math.cos(lat) * Math.cos(lon) * d[0] + Math.cos(lat) * Math.sin(lon) * d[1] + Math.sin(lat) * d[2];
    const range = Math.hypot(east, north, up);
    const az = ((0, units_js_1.toDegrees)(Math.atan2(east, north)) + 360) % 360;
    const el = (0, units_js_1.toDegrees)(Math.asin(up / Math.max(range, 1e-12)));
    return { azimuthDeg: az, elevationDeg: el, rangeM: range };
}
function relativeEcef(a, b) { return (0, vector_js_1.sub3)(geodeticToEcef(b), geodeticToEcef(a)); }
function midpointEcef(a, b) { const ea = geodeticToEcef(a), eb = geodeticToEcef(b); return ecefToGeodetic((0, vector_js_1.add3)(ea, eb).map((v) => v / 2)); }
//# sourceMappingURL=geodesy.js.map