"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinearKalmanFilter = void 0;
exports.complementaryFilter = complementaryFilter;
exports.lowPass = lowPass;
exports.highPass = highPass;
const matrix_js_1 = require("./matrix.js");
class LinearKalmanFilter {
    state;
    constructor(initialState, initialCovariance) { this.state = { x: [...initialState], covariance: initialCovariance ?? (0, matrix_js_1.identity)(initialState.length) }; }
    predict(transition, processNoise, controlMatrix, control) {
        const predicted = (0, matrix_js_1.matrixVectorMul)(transition, this.state.x);
        if (controlMatrix && control) {
            const u = (0, matrix_js_1.matrixVectorMul)(controlMatrix, control);
            for (let i = 0; i < predicted.length; i++)
                predicted[i] = (predicted[i] ?? 0) + (u[i] ?? 0);
        }
        this.state = { x: predicted, covariance: (0, matrix_js_1.matrixAdd)((0, matrix_js_1.matrixMul)((0, matrix_js_1.matrixMul)(transition, this.state.covariance), (0, matrix_js_1.transpose)(transition)), processNoise) };
        return this.current();
    }
    update(measurement, observation, measurementNoise) {
        const innovation = measurement.map((z, i) => z - ((0, matrix_js_1.matrixVectorMul)(observation, this.state.x)[i] ?? 0));
        const s = (0, matrix_js_1.matrixAdd)((0, matrix_js_1.matrixMul)((0, matrix_js_1.matrixMul)(observation, this.state.covariance), (0, matrix_js_1.transpose)(observation)), measurementNoise);
        const k = (0, matrix_js_1.matrixMul)((0, matrix_js_1.matrixMul)(this.state.covariance, (0, matrix_js_1.transpose)(observation)), (0, matrix_js_1.inverse)(s));
        const correction = (0, matrix_js_1.matrixVectorMul)(k, innovation);
        const x = this.state.x.map((v, i) => v + (correction[i] ?? 0));
        const iMat = (0, matrix_js_1.identity)(this.state.x.length);
        const covariance = (0, matrix_js_1.matrixMul)((0, matrix_js_1.matrixSub)(iMat, (0, matrix_js_1.matrixMul)(k, observation)), this.state.covariance);
        this.state = { x, covariance };
        return this.current();
    }
    current() { return { x: [...this.state.x], covariance: this.state.covariance.map((r) => [...r]) }; }
}
exports.LinearKalmanFilter = LinearKalmanFilter;
function complementaryFilter(previous, gyroRatePerSecond, measurement, dtSeconds, alpha = 0.98) { return alpha * (previous + gyroRatePerSecond * dtSeconds) + (1 - alpha) * measurement; }
function lowPass(previous, input, alpha) { return previous + alpha * (input - previous); }
function highPass(previousOutput, currentInput, previousInput, alpha) { return alpha * (previousOutput + currentInput - previousInput); }
//# sourceMappingURL=navigation.js.map