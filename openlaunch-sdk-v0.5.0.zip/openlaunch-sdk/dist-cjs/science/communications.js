"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dopplerShiftHz = exports.shannonCapacityBps = exports.linearToDb = exports.dbToLinear = exports.thermalNoiseDbw = exports.eirpDbw = exports.antennaGainDb = exports.antennaGainLinear = exports.freeSpacePathLossDb = exports.roundTripLightTimeSeconds = exports.lightTimeSeconds = exports.wavelength = void 0;
exports.linkMarginDb = linkMarginDb;
const constants_js_1 = require("./constants.js");
const wavelength = (frequencyHz) => constants_js_1.PHYSICS.speedOfLight / frequencyHz;
exports.wavelength = wavelength;
const lightTimeSeconds = (distanceM) => distanceM / constants_js_1.PHYSICS.speedOfLight;
exports.lightTimeSeconds = lightTimeSeconds;
const roundTripLightTimeSeconds = (distanceM) => 2 * (0, exports.lightTimeSeconds)(distanceM);
exports.roundTripLightTimeSeconds = roundTripLightTimeSeconds;
const freeSpacePathLossDb = (distanceM, frequencyHz) => 20 * Math.log10(4 * Math.PI * distanceM * frequencyHz / constants_js_1.PHYSICS.speedOfLight);
exports.freeSpacePathLossDb = freeSpacePathLossDb;
const antennaGainLinear = (diameterM, frequencyHz, efficiency = 0.6) => efficiency * (Math.PI * diameterM / (0, exports.wavelength)(frequencyHz)) ** 2;
exports.antennaGainLinear = antennaGainLinear;
const antennaGainDb = (diameterM, frequencyHz, efficiency = 0.6) => 10 * Math.log10((0, exports.antennaGainLinear)(diameterM, frequencyHz, efficiency));
exports.antennaGainDb = antennaGainDb;
const eirpDbw = (transmitPowerW, antennaGainDbValue, lossesDb = 0) => 10 * Math.log10(transmitPowerW) + antennaGainDbValue - lossesDb;
exports.eirpDbw = eirpDbw;
const thermalNoiseDbw = (temperatureK, bandwidthHz) => 10 * Math.log10(constants_js_1.PHYSICS.boltzmann * temperatureK * bandwidthHz);
exports.thermalNoiseDbw = thermalNoiseDbw;
const dbToLinear = (db) => 10 ** (db / 10);
exports.dbToLinear = dbToLinear;
const linearToDb = (linear) => 10 * Math.log10(linear);
exports.linearToDb = linearToDb;
const shannonCapacityBps = (bandwidthHz, snrLinear) => bandwidthHz * Math.log2(1 + snrLinear);
exports.shannonCapacityBps = shannonCapacityBps;
const dopplerShiftHz = (frequencyHz, radialVelocityMps) => -frequencyHz * radialVelocityMps / constants_js_1.PHYSICS.speedOfLight;
exports.dopplerShiftHz = dopplerShiftHz;
function linkMarginDb(input) {
    const eirp = (0, exports.eirpDbw)(input.transmitPowerW, input.txGainDb);
    const receivedDbw = eirp + input.rxGainDb - (0, exports.freeSpacePathLossDb)(input.distanceM, input.frequencyHz) - (input.systemLossesDb ?? 0);
    const n0DbwPerHz = 10 * Math.log10(constants_js_1.PHYSICS.boltzmann * (input.noiseTemperatureK ?? 290));
    const ebN0 = receivedDbw - n0DbwPerHz - 10 * Math.log10(input.dataRateBps ?? 1);
    return ebN0 - (input.requiredEbN0Db ?? 0);
}
//# sourceMappingURL=communications.js.map