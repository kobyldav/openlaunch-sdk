"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.firstOrderTimeConstantAlpha = exports.PIDController = void 0;
class PIDController {
    options;
    integral = 0;
    previousError;
    constructor(options) {
        this.options = options;
    }
    update(setpoint, measurement, dtSeconds) {
        const error = setpoint - measurement;
        this.integral += error * dtSeconds;
        this.integral = Math.max(this.options.integralMin ?? -Infinity, Math.min(this.options.integralMax ?? Infinity, this.integral));
        const derivative = this.previousError === undefined || dtSeconds <= 0 ? 0 : (error - this.previousError) / dtSeconds;
        this.previousError = error;
        const output = this.options.kp * error + this.options.ki * this.integral + this.options.kd * derivative;
        return Math.max(this.options.outputMin ?? -Infinity, Math.min(this.options.outputMax ?? Infinity, output));
    }
    reset() { this.integral = 0; this.previousError = undefined; }
}
exports.PIDController = PIDController;
const firstOrderTimeConstantAlpha = (dtSeconds, timeConstantSeconds) => dtSeconds / (timeConstantSeconds + dtSeconds);
exports.firstOrderTimeConstantAlpha = firstOrderTimeConstantAlpha;
//# sourceMappingURL=control.js.map