"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storageDays = exports.compressionResultBits = exports.transmissionTimeSeconds = exports.dataVolumeBits = void 0;
exports.downlinkBalance = downlinkBalance;
exports.dailyDataBudget = dailyDataBudget;
const dataVolumeBits = (bitrateBps, durationSeconds) => bitrateBps * durationSeconds;
exports.dataVolumeBits = dataVolumeBits;
const transmissionTimeSeconds = (bits, bitrateBps) => bits / bitrateBps;
exports.transmissionTimeSeconds = transmissionTimeSeconds;
const compressionResultBits = (originalBits, compressionRatio) => originalBits / compressionRatio;
exports.compressionResultBits = compressionResultBits;
const storageDays = (storageBits, generatedBitsPerDay) => storageBits / generatedBitsPerDay;
exports.storageDays = storageDays;
function downlinkBalance(generatedBps, downlinkBps, contactFraction) { const capacity = downlinkBps * contactFraction; return { netBps: capacity - generatedBps, stable: capacity >= generatedBps }; }
function dailyDataBudget(instruments) { return instruments.reduce((sum, item) => sum + item.rateBps * item.dutyCycle * 86400, 0); }
//# sourceMappingURL=data.js.map