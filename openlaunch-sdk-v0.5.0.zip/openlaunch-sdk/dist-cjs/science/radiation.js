"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.singleEventProbability = exports.inverseSquareDoseRate = exports.shieldingTransmission = exports.accumulatedDoseSv = void 0;
const accumulatedDoseSv = (doseRateSvPerHour, hours, shieldingFactor = 1) => doseRateSvPerHour * hours * shieldingFactor;
exports.accumulatedDoseSv = accumulatedDoseSv;
const shieldingTransmission = (arealDensityKgM2, attenuationCoefficientM2Kg) => Math.exp(-arealDensityKgM2 * attenuationCoefficientM2Kg);
exports.shieldingTransmission = shieldingTransmission;
const inverseSquareDoseRate = (referenceDoseRate, referenceDistanceM, distanceM) => referenceDoseRate * (referenceDistanceM / distanceM) ** 2;
exports.inverseSquareDoseRate = inverseSquareDoseRate;
const singleEventProbability = (fluxPerM2S, crossSectionM2, durationSeconds) => 1 - Math.exp(-fluxPerM2S * crossSectionM2 * durationSeconds);
exports.singleEventProbability = singleEventProbability;
//# sourceMappingURL=radiation.js.map