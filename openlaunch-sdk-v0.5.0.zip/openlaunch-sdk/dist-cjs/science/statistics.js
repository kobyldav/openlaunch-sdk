"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.correlation = exports.median = exports.stddev = exports.mean = exports.sum = void 0;
exports.variance = variance;
exports.percentile = percentile;
exports.covariance = covariance;
exports.linearRegression = linearRegression;
exports.gaussianRandom = gaussianRandom;
exports.monteCarlo = monteCarlo;
exports.monteCarloScalar = monteCarloScalar;
exports.rootMeanSquare = rootMeanSquare;
const sum = (values) => values.reduce((a, b) => a + b, 0);
exports.sum = sum;
const mean = (values) => values.length ? (0, exports.sum)(values) / values.length : Number.NaN;
exports.mean = mean;
function variance(values, sample = false) { if (values.length <= (sample ? 1 : 0))
    return Number.NaN; const m = (0, exports.mean)(values); return values.reduce((s, x) => s + (x - m) ** 2, 0) / (values.length - (sample ? 1 : 0)); }
const stddev = (values, sample = false) => Math.sqrt(variance(values, sample));
exports.stddev = stddev;
function percentile(values, p) { if (!values.length)
    return Number.NaN; const sorted = [...values].sort((a, b) => a - b); const idx = Math.max(0, Math.min(1, p)) * (sorted.length - 1); const lo = Math.floor(idx), hi = Math.ceil(idx), t = idx - lo; return (sorted[lo] ?? 0) * (1 - t) + (sorted[hi] ?? 0) * t; }
const median = (values) => percentile(values, 0.5);
exports.median = median;
function covariance(a, b, sample = false) { const n = Math.min(a.length, b.length); if (n <= (sample ? 1 : 0))
    return Number.NaN; const ma = (0, exports.mean)(a.slice(0, n)), mb = (0, exports.mean)(b.slice(0, n)); let s = 0; for (let i = 0; i < n; i++)
    s += ((a[i] ?? 0) - ma) * ((b[i] ?? 0) - mb); return s / (n - (sample ? 1 : 0)); }
const correlation = (a, b) => covariance(a, b) / ((0, exports.stddev)(a) * (0, exports.stddev)(b));
exports.correlation = correlation;
function linearRegression(x, y) { const n = Math.min(x.length, y.length); const xs = x.slice(0, n), ys = y.slice(0, n); const slope = covariance(xs, ys) / variance(xs); const intercept = (0, exports.mean)(ys) - slope * (0, exports.mean)(xs); const predictions = xs.map((v) => intercept + slope * v); const ssRes = ys.reduce((s, v, i) => s + (v - (predictions[i] ?? 0)) ** 2, 0); const my = (0, exports.mean)(ys); const ssTot = ys.reduce((s, v) => s + (v - my) ** 2, 0); return { slope, intercept, r2: ssTot === 0 ? 1 : 1 - ssRes / ssTot }; }
function gaussianRandom(meanValue = 0, standardDeviation = 1, random = Math.random) { const u1 = Math.max(Number.EPSILON, random()), u2 = random(); return meanValue + standardDeviation * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2); }
function monteCarlo(iterations, simulate) { return Array.from({ length: Math.max(0, Math.trunc(iterations)) }, (_, i) => simulate(i)); }
function monteCarloScalar(iterations, simulate) { const samples = monteCarlo(iterations, simulate); return { samples, mean: (0, exports.mean)(samples), stddev: (0, exports.stddev)(samples), p05: percentile(samples, 0.05), p50: percentile(samples, 0.5), p95: percentile(samples, 0.95) }; }
function rootMeanSquare(values) { return Math.sqrt((0, exports.mean)(values.map((x) => x * x))); }
//# sourceMappingURL=statistics.js.map