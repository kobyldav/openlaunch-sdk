"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.averageAcceleration = exports.impulse = exports.payloadFraction = exports.structuralCoefficient = exports.propellantMassFraction = exports.effectiveExhaustVelocity = exports.characteristicVelocity = exports.burnTime = exports.massFlowRate = exports.thrustToWeight = exports.massRatioForDeltaV = exports.specificImpulseFromExhaustVelocity = exports.exhaustVelocity = void 0;
exports.rocketEquationDeltaV = rocketEquationDeltaV;
exports.propellantRequired = propellantRequired;
exports.stageDeltaV = stageDeltaV;
exports.stagedRocketDeltaV = stagedRocketDeltaV;
const constants_js_1 = require("./constants.js");
const errors_js_1 = require("../errors.js");
const exhaustVelocity = (specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) => specificImpulseS * g0;
exports.exhaustVelocity = exhaustVelocity;
const specificImpulseFromExhaustVelocity = (velocityMps, g0 = constants_js_1.PHYSICS.standardGravity) => velocityMps / g0;
exports.specificImpulseFromExhaustVelocity = specificImpulseFromExhaustVelocity;
function rocketEquationDeltaV(initialMassKg, finalMassKg, specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) {
    if (!(initialMassKg > finalMassKg && finalMassKg > 0))
        throw new errors_js_1.ValidationError("Require initialMassKg > finalMassKg > 0");
    return specificImpulseS * g0 * Math.log(initialMassKg / finalMassKg);
}
const massRatioForDeltaV = (deltaVMps, specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) => Math.exp(deltaVMps / (specificImpulseS * g0));
exports.massRatioForDeltaV = massRatioForDeltaV;
function propellantRequired(initialMassKg, deltaVMps, specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) { return initialMassKg * (1 - 1 / (0, exports.massRatioForDeltaV)(deltaVMps, specificImpulseS, g0)); }
const thrustToWeight = (thrustN, massKg, gravityMps2 = constants_js_1.PHYSICS.standardGravity) => thrustN / (massKg * gravityMps2);
exports.thrustToWeight = thrustToWeight;
const massFlowRate = (thrustN, specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) => thrustN / (specificImpulseS * g0);
exports.massFlowRate = massFlowRate;
const burnTime = (propellantKg, thrustN, specificImpulseS, g0 = constants_js_1.PHYSICS.standardGravity) => propellantKg / (0, exports.massFlowRate)(thrustN, specificImpulseS, g0);
exports.burnTime = burnTime;
const characteristicVelocity = (chamberPressurePa, throatAreaM2, massFlowKgS) => chamberPressurePa * throatAreaM2 / massFlowKgS;
exports.characteristicVelocity = characteristicVelocity;
const effectiveExhaustVelocity = (thrustN, massFlowKgS) => thrustN / massFlowKgS;
exports.effectiveExhaustVelocity = effectiveExhaustVelocity;
function stageDeltaV(stage, payloadAboveKg = 0, g0 = constants_js_1.PHYSICS.standardGravity) {
    const initial = stage.dryMassKg + stage.propellantMassKg + payloadAboveKg;
    const final = stage.dryMassKg + payloadAboveKg;
    return rocketEquationDeltaV(initial, final, stage.specificImpulseS, g0);
}
function stagedRocketDeltaV(stagesBottomToTop, payloadKg = 0) {
    const per = [];
    for (let i = 0; i < stagesBottomToTop.length; i++) {
        let above = payloadKg;
        for (let j = i + 1; j < stagesBottomToTop.length; j++)
            above += stagesBottomToTop[j].dryMassKg + stagesBottomToTop[j].propellantMassKg;
        per.push(stageDeltaV(stagesBottomToTop[i], above));
    }
    return { totalDeltaVMps: per.reduce((a, b) => a + b, 0), perStageDeltaVMps: per };
}
const propellantMassFraction = (dryMassKg, propellantMassKg) => propellantMassKg / (dryMassKg + propellantMassKg);
exports.propellantMassFraction = propellantMassFraction;
const structuralCoefficient = (dryMassKg, propellantMassKg) => dryMassKg / (dryMassKg + propellantMassKg);
exports.structuralCoefficient = structuralCoefficient;
const payloadFraction = (payloadKg, initialMassKg) => payloadKg / initialMassKg;
exports.payloadFraction = payloadFraction;
const impulse = (thrustN, burnSeconds) => thrustN * burnSeconds;
exports.impulse = impulse;
const averageAcceleration = (thrustN, massKg, gravityMps2 = 0) => thrustN / massKg - gravityMps2;
exports.averageAcceleration = averageAcceleration;
//# sourceMappingURL=rocket.js.map