"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nodalPrecessionJ2 = exports.synchronousOrbitRadius = exports.circularOrbitAltitude = exports.c3FromHyperbolicExcess = exports.hyperbolicExcessFromC3 = exports.hillSphere = exports.sphereOfInfluence = exports.planeChangeDeltaV = exports.semiMajorAxisFromApsides = exports.eccentricityFromApsides = exports.apoapsisRadius = exports.periapsisRadius = exports.semiMajorAxisFromEnergy = exports.specificOrbitalEnergy = exports.visVivaVelocity = exports.meanMotion = exports.orbitalPeriod = exports.escapeVelocity = exports.circularVelocity = void 0;
exports.stateToOrbitalElements = stateToOrbitalElements;
exports.orbitalElementsToState = orbitalElementsToState;
exports.eccentricAnomalyFromTrue = eccentricAnomalyFromTrue;
exports.meanAnomalyFromEccentric = meanAnomalyFromEccentric;
exports.solveKepler = solveKepler;
exports.trueAnomalyFromEccentric = trueAnomalyFromEccentric;
exports.propagateTwoBody = propagateTwoBody;
const errors_js_1 = require("../errors.js");
const constants_js_1 = require("./constants.js");
const vector_js_1 = require("./vector.js");
const units_js_1 = require("./units.js");
const circularVelocity = (radiusM, mu = constants_js_1.BODIES.earth.mu) => Math.sqrt(mu / radiusM);
exports.circularVelocity = circularVelocity;
const escapeVelocity = (radiusM, mu = constants_js_1.BODIES.earth.mu) => Math.sqrt(2 * mu / radiusM);
exports.escapeVelocity = escapeVelocity;
const orbitalPeriod = (semiMajorAxisM, mu = constants_js_1.BODIES.earth.mu) => 2 * Math.PI * Math.sqrt(semiMajorAxisM ** 3 / mu);
exports.orbitalPeriod = orbitalPeriod;
const meanMotion = (semiMajorAxisM, mu = constants_js_1.BODIES.earth.mu) => Math.sqrt(mu / semiMajorAxisM ** 3);
exports.meanMotion = meanMotion;
const visVivaVelocity = (radiusM, semiMajorAxisM, mu = constants_js_1.BODIES.earth.mu) => Math.sqrt(mu * (2 / radiusM - 1 / semiMajorAxisM));
exports.visVivaVelocity = visVivaVelocity;
const specificOrbitalEnergy = (radiusM, velocityMps, mu = constants_js_1.BODIES.earth.mu) => velocityMps ** 2 / 2 - mu / radiusM;
exports.specificOrbitalEnergy = specificOrbitalEnergy;
const semiMajorAxisFromEnergy = (energy, mu = constants_js_1.BODIES.earth.mu) => -mu / (2 * energy);
exports.semiMajorAxisFromEnergy = semiMajorAxisFromEnergy;
const periapsisRadius = (a, e) => a * (1 - e);
exports.periapsisRadius = periapsisRadius;
const apoapsisRadius = (a, e) => a * (1 + e);
exports.apoapsisRadius = apoapsisRadius;
const eccentricityFromApsides = (rp, ra) => (ra - rp) / (ra + rp);
exports.eccentricityFromApsides = eccentricityFromApsides;
const semiMajorAxisFromApsides = (rp, ra) => (rp + ra) / 2;
exports.semiMajorAxisFromApsides = semiMajorAxisFromApsides;
const planeChangeDeltaV = (velocityMps, angleRad) => 2 * velocityMps * Math.sin(Math.abs(angleRad) / 2);
exports.planeChangeDeltaV = planeChangeDeltaV;
const sphereOfInfluence = (semiMajorAxisM, bodyMassKg, parentMassKg) => semiMajorAxisM * (bodyMassKg / parentMassKg) ** (2 / 5);
exports.sphereOfInfluence = sphereOfInfluence;
const hillSphere = (semiMajorAxisM, eccentricity, bodyMassKg, parentMassKg) => semiMajorAxisM * (1 - eccentricity) * (bodyMassKg / (3 * parentMassKg)) ** (1 / 3);
exports.hillSphere = hillSphere;
const hyperbolicExcessFromC3 = (c3) => Math.sqrt(Math.max(0, c3));
exports.hyperbolicExcessFromC3 = hyperbolicExcessFromC3;
const c3FromHyperbolicExcess = (vInfinityMps) => vInfinityMps * vInfinityMps;
exports.c3FromHyperbolicExcess = c3FromHyperbolicExcess;
const circularOrbitAltitude = (periodSeconds, bodyRadiusM = constants_js_1.BODIES.earth.radius, mu = constants_js_1.BODIES.earth.mu) => (mu * (periodSeconds / (2 * Math.PI)) ** 2) ** (1 / 3) - bodyRadiusM;
exports.circularOrbitAltitude = circularOrbitAltitude;
const synchronousOrbitRadius = (rotationPeriodSeconds, mu = constants_js_1.BODIES.earth.mu) => (mu * (rotationPeriodSeconds / (2 * Math.PI)) ** 2) ** (1 / 3);
exports.synchronousOrbitRadius = synchronousOrbitRadius;
const nodalPrecessionJ2 = (a, e, inclinationRad, j2 = 1.08262668e-3, radiusM = constants_js_1.BODIES.earth.radius, mu = constants_js_1.BODIES.earth.mu) => {
    const n = (0, exports.meanMotion)(a, mu);
    return -1.5 * j2 * n * (radiusM / a) ** 2 * Math.cos(inclinationRad) / (1 - e * e) ** 2;
};
exports.nodalPrecessionJ2 = nodalPrecessionJ2;
function stateToOrbitalElements(state, mu = constants_js_1.BODIES.earth.mu) {
    const r = state.positionM, v = state.velocityMps;
    const rmag = (0, vector_js_1.norm3)(r), vmag = (0, vector_js_1.norm3)(v);
    if (rmag === 0)
        throw new errors_js_1.ValidationError("Position magnitude cannot be zero");
    const h = (0, vector_js_1.cross3)(r, v), hmag = (0, vector_js_1.norm3)(h);
    if (hmag === 0)
        throw new errors_js_1.ValidationError("Angular momentum cannot be zero");
    const k = [0, 0, 1];
    const n = (0, vector_js_1.cross3)(k, h), nmag = (0, vector_js_1.norm3)(n);
    const evec = (0, vector_js_1.sub3)((0, vector_js_1.scale3)(r, (vmag * vmag - mu / rmag) / mu), (0, vector_js_1.scale3)(v, (0, vector_js_1.dot3)(r, v) / mu));
    const e = (0, vector_js_1.norm3)(evec);
    const energy = (0, exports.specificOrbitalEnergy)(rmag, vmag, mu);
    const a = Math.abs(energy) < 1e-15 ? Number.POSITIVE_INFINITY : (0, exports.semiMajorAxisFromEnergy)(energy, mu);
    const i = Math.acos(Math.max(-1, Math.min(1, h[2] / hmag)));
    let raan = nmag < 1e-12 ? 0 : Math.atan2(n[1], n[0]);
    raan = (0, units_js_1.normalizeRadians)(raan);
    let argp = 0;
    if (nmag >= 1e-12 && e > 1e-12) {
        argp = (0, vector_js_1.angle3)(n, evec);
        if (evec[2] < 0)
            argp = 2 * Math.PI - argp;
    }
    let nu = 0;
    if (e > 1e-12) {
        nu = (0, vector_js_1.angle3)(evec, r);
        if ((0, vector_js_1.dot3)(r, v) < 0)
            nu = 2 * Math.PI - nu;
    }
    else if (nmag >= 1e-12) {
        nu = (0, vector_js_1.angle3)(n, r);
        if (r[2] < 0)
            nu = 2 * Math.PI - nu;
    }
    else {
        nu = (0, units_js_1.normalizeRadians)(Math.atan2(r[1], r[0]));
    }
    return {
        semiMajorAxisM: a,
        eccentricity: e,
        inclinationRad: i,
        raanRad: raan,
        argumentOfPeriapsisRad: (0, units_js_1.normalizeRadians)(argp),
        trueAnomalyRad: (0, units_js_1.normalizeRadians)(nu),
        semiLatusRectumM: hmag * hmag / mu,
        specificAngularMomentum: hmag,
        specificOrbitalEnergy: energy,
    };
}
function orbitalElementsToState(elements, mu = constants_js_1.BODIES.earth.mu) {
    const { semiMajorAxisM: a, eccentricity: e, inclinationRad: i, raanRad: O, argumentOfPeriapsisRad: w, trueAnomalyRad: nu } = elements;
    const p = a * (1 - e * e);
    if (!(p > 0))
        throw new errors_js_1.ValidationError("Semi-latus rectum must be positive");
    const rmag = p / (1 + e * Math.cos(nu));
    const rp = [rmag * Math.cos(nu), rmag * Math.sin(nu), 0];
    const factor = Math.sqrt(mu / p);
    const vp = [-factor * Math.sin(nu), factor * (e + Math.cos(nu)), 0];
    const cO = Math.cos(O), sO = Math.sin(O), ci = Math.cos(i), si = Math.sin(i), cw = Math.cos(w), sw = Math.sin(w);
    const transform = (q) => [
        (cO * cw - sO * sw * ci) * q[0] + (-cO * sw - sO * cw * ci) * q[1],
        (sO * cw + cO * sw * ci) * q[0] + (-sO * sw + cO * cw * ci) * q[1],
        (sw * si) * q[0] + (cw * si) * q[1],
    ];
    return { positionM: transform(rp), velocityMps: transform(vp) };
}
function eccentricAnomalyFromTrue(trueAnomalyRad, eccentricity) {
    return 2 * Math.atan2(Math.sqrt(1 - eccentricity) * Math.sin(trueAnomalyRad / 2), Math.sqrt(1 + eccentricity) * Math.cos(trueAnomalyRad / 2));
}
function meanAnomalyFromEccentric(eccentricAnomalyRad, eccentricity) { return eccentricAnomalyRad - eccentricity * Math.sin(eccentricAnomalyRad); }
function solveKepler(meanAnomalyRad, eccentricity, tolerance = 1e-12, maxIterations = 50) {
    let eAnomaly = eccentricity < 0.8 ? meanAnomalyRad : Math.PI;
    for (let i = 0; i < maxIterations; i++) {
        const f = eAnomaly - eccentricity * Math.sin(eAnomaly) - meanAnomalyRad;
        const fp = 1 - eccentricity * Math.cos(eAnomaly);
        const next = eAnomaly - f / fp;
        if (Math.abs(next - eAnomaly) < tolerance)
            return next;
        eAnomaly = next;
    }
    return eAnomaly;
}
function trueAnomalyFromEccentric(eccentricAnomalyRad, eccentricity) {
    return (0, units_js_1.normalizeRadians)(2 * Math.atan2(Math.sqrt(1 + eccentricity) * Math.sin(eccentricAnomalyRad / 2), Math.sqrt(1 - eccentricity) * Math.cos(eccentricAnomalyRad / 2)));
}
function propagateTwoBody(elements, deltaTimeSeconds, mu = constants_js_1.BODIES.earth.mu) {
    if (elements.eccentricity >= 1)
        throw new errors_js_1.ValidationError("This propagator currently supports elliptical orbits (e < 1)");
    const e0 = eccentricAnomalyFromTrue(elements.trueAnomalyRad, elements.eccentricity);
    const m0 = meanAnomalyFromEccentric(e0, elements.eccentricity);
    const m = m0 + (0, exports.meanMotion)(elements.semiMajorAxisM, mu) * deltaTimeSeconds;
    const e = solveKepler(m, elements.eccentricity);
    const nu = trueAnomalyFromEccentric(e, elements.eccentricity);
    return orbitalElementsToState({ ...elements, trueAnomalyRad: nu }, mu);
}
//# sourceMappingURL=orbits.js.map