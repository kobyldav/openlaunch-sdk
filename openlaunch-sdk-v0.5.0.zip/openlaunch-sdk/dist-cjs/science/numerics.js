"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.remap = exports.inverseLerp = exports.lerp = exports.clamp = void 0;
exports.bisection = bisection;
exports.newtonRaphson = newtonRaphson;
exports.derivativeCentral = derivativeCentral;
exports.integrateTrapezoid = integrateTrapezoid;
exports.integrateSimpson = integrateSimpson;
exports.rk4 = rk4;
const errors_js_1 = require("../errors.js");
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
exports.clamp = clamp;
const lerp = (a, b, t) => a + (b - a) * t;
exports.lerp = lerp;
const inverseLerp = (a, b, value) => a === b ? 0 : (value - a) / (b - a);
exports.inverseLerp = inverseLerp;
const remap = (value, inMin, inMax, outMin, outMax) => (0, exports.lerp)(outMin, outMax, (0, exports.inverseLerp)(inMin, inMax, value));
exports.remap = remap;
function bisection(fn, low, high, tolerance = 1e-10, maxIterations = 100) {
    let fl = fn(low), fh = fn(high);
    if (fl * fh > 0)
        throw new errors_js_1.ValidationError("Bisection requires a sign change over the interval");
    for (let i = 0; i < maxIterations; i++) {
        const mid = (low + high) / 2, fm = fn(mid);
        if (Math.abs(fm) < tolerance || Math.abs(high - low) < tolerance)
            return mid;
        if (fl * fm <= 0) {
            high = mid;
            fh = fm;
        }
        else {
            low = mid;
            fl = fm;
        }
    }
    return (low + high) / 2;
}
function newtonRaphson(fn, derivative, initial, tolerance = 1e-10, maxIterations = 50) { let x = initial; for (let i = 0; i < maxIterations; i++) {
    const d = derivative(x);
    if (Math.abs(d) < 1e-15)
        break;
    const next = x - fn(x) / d;
    if (Math.abs(next - x) < tolerance)
        return next;
    x = next;
} return x; }
function derivativeCentral(fn, x, h = 1e-5) { return (fn(x + h) - fn(x - h)) / (2 * h); }
function integrateTrapezoid(fn, a, b, steps = 1000) { const n = Math.max(1, Math.trunc(steps)), h = (b - a) / n; let sum = 0.5 * (fn(a) + fn(b)); for (let i = 1; i < n; i++)
    sum += fn(a + i * h); return sum * h; }
function integrateSimpson(fn, a, b, steps = 1000) { let n = Math.max(2, Math.trunc(steps)); if (n % 2)
    n++; const h = (b - a) / n; let sum = fn(a) + fn(b); for (let i = 1; i < n; i++)
    sum += (i % 2 ? 4 : 2) * fn(a + i * h); return sum * h / 3; }
function rk4(state, derivative, t, dt) {
    const add = (a, b, k) => a.map((v, i) => v + k * (b[i] ?? 0));
    const k1 = derivative(state, t), k2 = derivative(add(state, k1, dt / 2), t + dt / 2), k3 = derivative(add(state, k2, dt / 2), t + dt / 2), k4 = derivative(add(state, k3, dt), t + dt);
    return state.map((v, i) => v + dt * ((k1[i] ?? 0) + 2 * (k2[i] ?? 0) + 2 * (k3[i] ?? 0) + (k4[i] ?? 0)) / 6);
}
//# sourceMappingURL=numerics.js.map