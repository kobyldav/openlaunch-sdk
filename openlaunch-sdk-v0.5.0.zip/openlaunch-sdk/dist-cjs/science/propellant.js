"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pressurantMoles = exports.tankVolumeM3 = exports.mixtureComponentMasses = exports.remainingAfterBoiloffKg = exports.boiloffMassKg = void 0;
const boiloffMassKg = (initialMassKg, dailyFraction, days) => initialMassKg * (1 - (1 - dailyFraction) ** days);
exports.boiloffMassKg = boiloffMassKg;
const remainingAfterBoiloffKg = (initialMassKg, dailyFraction, days) => initialMassKg * (1 - dailyFraction) ** days;
exports.remainingAfterBoiloffKg = remainingAfterBoiloffKg;
const mixtureComponentMasses = (totalPropellantKg, oxidizerFuelRatio) => ({ oxidizerKg: totalPropellantKg * oxidizerFuelRatio / (1 + oxidizerFuelRatio), fuelKg: totalPropellantKg / (1 + oxidizerFuelRatio) });
exports.mixtureComponentMasses = mixtureComponentMasses;
const tankVolumeM3 = (propellantMassKg, densityKgM3, ullageFraction = 0.03) => propellantMassKg / densityKgM3 / (1 - ullageFraction);
exports.tankVolumeM3 = tankVolumeM3;
const pressurantMoles = (pressurePa, volumeM3, temperatureK) => pressurePa * volumeM3 / (8.31446261815324 * temperatureK);
exports.pressurantMoles = pressurantMoles;
//# sourceMappingURL=propellant.js.map