"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cabinOxygenMassKg = exports.metabolicHeatW = exports.co2ProductionKg = exports.DEFAULT_CREW_RATES = void 0;
exports.consumablesForMission = consumablesForMission;
exports.DEFAULT_CREW_RATES = { oxygenKgPerPersonDay: 0.84, waterKgPerPersonDay: 3.5, foodKgPerPersonDay: 1.8 };
function consumablesForMission(crew, days, recycling = {}, reserveFraction = 0.2, rates = exports.DEFAULT_CREW_RATES) {
    const factor = crew * days * (1 + reserveFraction);
    const oxygenKg = factor * rates.oxygenKgPerPersonDay * (1 - (recycling.oxygenRecovery ?? 0));
    const waterKg = factor * rates.waterKgPerPersonDay * (1 - (recycling.waterRecovery ?? 0));
    const foodKg = factor * rates.foodKgPerPersonDay;
    return { oxygenKg, waterKg, foodKg, totalKg: oxygenKg + waterKg + foodKg };
}
const co2ProductionKg = (crew, days, kgPerPersonDay = 1) => crew * days * kgPerPersonDay;
exports.co2ProductionKg = co2ProductionKg;
const metabolicHeatW = (crew, wattsPerPerson = 100) => crew * wattsPerPerson;
exports.metabolicHeatW = metabolicHeatW;
const cabinOxygenMassKg = (pressurePa, volumeM3, temperatureK, oxygenMolarFraction = 0.21) => pressurePa * volumeM3 * oxygenMolarFraction * 0.031998 / (8.31446261815324 * temperatureK);
exports.cabinOxygenMassKg = cabinOxygenMassKg;
//# sourceMappingURL=life-support.js.map