"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rotationBoostMps = exports.minimumReachableInclinationDeg = exports.launchAzimuthForInclination = void 0;
exports.totalDeltaVBudget = totalDeltaVBudget;
exports.leoReference = leoReference;
exports.marsMissionReference = marsMissionReference;
exports.payloadMassAfterDeltaV = payloadMassAfterDeltaV;
exports.availableDeltaV = availableDeltaV;
const constants_js_1 = require("./constants.js");
const geodesy_js_1 = require("./geodesy.js");
const transfers_js_1 = require("./transfers.js");
const orbits_js_1 = require("./orbits.js");
const rocket_js_1 = require("./rocket.js");
const thermal_js_1 = require("./thermal.js");
const communications_js_1 = require("./communications.js");
function totalDeltaVBudget(items) {
    const nominalMps = items.reduce((sum, item) => sum + item.deltaVMps, 0);
    const withReservesMps = items.reduce((sum, item) => sum + item.deltaVMps * (1 + (item.reserveFraction ?? 0)), 0);
    return { nominalMps, withReservesMps };
}
const launchAzimuthForInclination = (latitudeRad, inclinationRad) => Math.asin(Math.cos(inclinationRad) / Math.cos(latitudeRad));
exports.launchAzimuthForInclination = launchAzimuthForInclination;
const minimumReachableInclinationDeg = (launchLatitudeDeg) => Math.abs(launchLatitudeDeg);
exports.minimumReachableInclinationDeg = minimumReachableInclinationDeg;
const rotationBoostMps = (latitudeDeg, eastwardComponent = 1) => (0, geodesy_js_1.earthRotationSurfaceSpeed)(latitudeDeg) * eastwardComponent;
exports.rotationBoostMps = rotationBoostMps;
function leoReference(altitudeM = 200_000) {
    const radiusM = constants_js_1.BODIES.earth.radius + altitudeM;
    const circularVelocityMps = (0, orbits_js_1.circularVelocity)(radiusM, constants_js_1.BODIES.earth.mu);
    return { radiusM, circularVelocityMps, escapeVelocityMps: (0, orbits_js_1.escapeVelocity)(radiusM, constants_js_1.BODIES.earth.mu), orbitalPeriodMinutes: 2 * Math.PI * Math.sqrt(radiusM ** 3 / constants_js_1.BODIES.earth.mu) / 60 };
}
function marsMissionReference(parkingAltitudeM = 200_000) {
    const transfer = (0, transfers_js_1.earthMarsHohmann)();
    const departure = (0, transfers_js_1.patchedConicDeparture)(constants_js_1.BODIES.earth.semiMajorAxis, constants_js_1.BODIES.mars.semiMajorAxis, constants_js_1.BODIES.earth.radius + parkingAltitudeM, constants_js_1.BODIES.earth.mu);
    return {
        transferTimeDays: transfer.transferTimeDays,
        synodicPeriodDays: transfer.synodicPeriodDays,
        departurePhaseAngleDeg: transfer.departurePhaseAngleDeg,
        earthDepartureVInfinityMps: transfer.earthDepartureVInfinityMps,
        earthDepartureC3M2ps2: transfer.earthDepartureC3M2ps2,
        transMarsInjectionDeltaVMps: departure.injectionDeltaVMps,
        solarFluxAtMarsWm2: (0, thermal_js_1.solarFluxAtDistance)(constants_js_1.BODIES.mars.semiMajorAxis),
        oneWayLightTimeAtMeanDistanceSeconds: (0, communications_js_1.lightTimeSeconds)(Math.abs(constants_js_1.BODIES.mars.semiMajorAxis - constants_js_1.BODIES.earth.semiMajorAxis)),
    };
}
function payloadMassAfterDeltaV(initialMassKg, deltaVMps, ispSeconds) { return initialMassKg / Math.exp(deltaVMps / (ispSeconds * constants_js_1.PHYSICS.standardGravity)); }
function availableDeltaV(initialMassKg, finalMassKg, ispSeconds) { return (0, rocket_js_1.rocketEquationDeltaV)(initialMassKg, finalMassKg, ispSeconds); }
//# sourceMappingURL=mission.js.map