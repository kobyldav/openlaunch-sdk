"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blackbodyPeakWavelengthM = exports.magnitudeDifferenceToFluxRatio = exports.apparentMagnitude = exports.distanceModulus = exports.fluxFromLuminosity = exports.luminosityFromRadiusTemperature = exports.angularDiameterRad = void 0;
const constants_js_1 = require("./constants.js");
const angularDiameterRad = (diameterM, distanceM) => 2 * Math.atan2(diameterM / 2, distanceM);
exports.angularDiameterRad = angularDiameterRad;
const luminosityFromRadiusTemperature = (radiusM, temperatureK) => 4 * Math.PI * radiusM ** 2 * constants_js_1.PHYSICS.stefanBoltzmann * temperatureK ** 4;
exports.luminosityFromRadiusTemperature = luminosityFromRadiusTemperature;
const fluxFromLuminosity = (luminosityW, distanceM) => luminosityW / (4 * Math.PI * distanceM ** 2);
exports.fluxFromLuminosity = fluxFromLuminosity;
const distanceModulus = (distanceParsec) => 5 * Math.log10(distanceParsec) - 5;
exports.distanceModulus = distanceModulus;
const apparentMagnitude = (absoluteMagnitude, distanceParsec) => absoluteMagnitude + (0, exports.distanceModulus)(distanceParsec);
exports.apparentMagnitude = apparentMagnitude;
const magnitudeDifferenceToFluxRatio = (deltaMagnitude) => 10 ** (-0.4 * deltaMagnitude);
exports.magnitudeDifferenceToFluxRatio = magnitudeDifferenceToFluxRatio;
const blackbodyPeakWavelengthM = (temperatureK) => 2.897771955e-3 / temperatureK;
exports.blackbodyPeakWavelengthM = blackbodyPeakWavelengthM;
//# sourceMappingURL=astronomy.js.map