"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.quatFromAxisAngle = exports.quatMultiply = exports.quatConjugate = exports.quatNormalize = exports.quatNorm = exports.quatIdentity = void 0;
exports.quatRotateVector = quatRotateVector;
exports.quatFromEuler = quatFromEuler;
exports.quatToEuler = quatToEuler;
exports.quatSlerp = quatSlerp;
const vector_js_1 = require("./vector.js");
const quatIdentity = () => [1, 0, 0, 0];
exports.quatIdentity = quatIdentity;
const quatNorm = (q) => Math.hypot(q[0], q[1], q[2], q[3]);
exports.quatNorm = quatNorm;
const quatNormalize = (q) => { const n = (0, exports.quatNorm)(q); return n === 0 ? (0, exports.quatIdentity)() : [q[0] / n, q[1] / n, q[2] / n, q[3] / n]; };
exports.quatNormalize = quatNormalize;
const quatConjugate = (q) => [q[0], -q[1], -q[2], -q[3]];
exports.quatConjugate = quatConjugate;
const quatMultiply = (a, b) => [
    a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3],
    a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
    a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
    a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0],
];
exports.quatMultiply = quatMultiply;
const quatFromAxisAngle = (axis, angleRad) => { const n = (0, vector_js_1.normalize3)(axis), h = angleRad / 2, s = Math.sin(h); return (0, exports.quatNormalize)([Math.cos(h), n[0] * s, n[1] * s, n[2] * s]); };
exports.quatFromAxisAngle = quatFromAxisAngle;
function quatRotateVector(q, v) { const p = [0, v[0], v[1], v[2]]; const r = (0, exports.quatMultiply)((0, exports.quatMultiply)(q, p), (0, exports.quatConjugate)(q)); return [r[1], r[2], r[3]]; }
function quatFromEuler(rollRad, pitchRad, yawRad) {
    const cr = Math.cos(rollRad / 2), sr = Math.sin(rollRad / 2), cp = Math.cos(pitchRad / 2), sp = Math.sin(pitchRad / 2), cy = Math.cos(yawRad / 2), sy = Math.sin(yawRad / 2);
    return (0, exports.quatNormalize)([cr * cp * cy + sr * sp * sy, sr * cp * cy - cr * sp * sy, cr * sp * cy + sr * cp * sy, cr * cp * sy - sr * sp * cy]);
}
function quatToEuler(qIn) {
    const q = (0, exports.quatNormalize)(qIn);
    const [w, x, y, z] = q;
    const sinr = 2 * (w * x + y * z), cosr = 1 - 2 * (x * x + y * y);
    const sinp = 2 * (w * y - z * x);
    const siny = 2 * (w * z + x * y), cosy = 1 - 2 * (y * y + z * z);
    return { rollRad: Math.atan2(sinr, cosr), pitchRad: Math.abs(sinp) >= 1 ? Math.sign(sinp) * Math.PI / 2 : Math.asin(sinp), yawRad: Math.atan2(siny, cosy) };
}
function quatSlerp(aIn, bIn, t) {
    let a = (0, exports.quatNormalize)(aIn), b = (0, exports.quatNormalize)(bIn);
    let dot = a.reduce((s, v, i) => s + v * b[i], 0);
    if (dot < 0) {
        b = [-b[0], -b[1], -b[2], -b[3]];
        dot = -dot;
    }
    if (dot > 0.9995)
        return (0, exports.quatNormalize)([a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]), a[2] + t * (b[2] - a[2]), a[3] + t * (b[3] - a[3])]);
    const theta0 = Math.acos(Math.max(-1, Math.min(1, dot))), theta = theta0 * t, s0 = Math.cos(theta) - dot * Math.sin(theta) / Math.sin(theta0), s1 = Math.sin(theta) / Math.sin(theta0);
    return [s0 * a[0] + s1 * b[0], s0 * a[1] + s1 * b[1], s0 * a[2] + s1 * b[2], s0 * a[3] + s1 * b[3]];
}
//# sourceMappingURL=quaternion.js.map