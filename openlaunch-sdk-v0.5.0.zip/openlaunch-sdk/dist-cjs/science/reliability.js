"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.availability = exports.parallelReliability = exports.seriesReliability = exports.failureRateFromMtbf = exports.mtbfFromFailureRate = exports.failureProbability = exports.exponentialReliability = void 0;
exports.kOfNReliability = kOfNReliability;
exports.combination = combination;
const exponentialReliability = (failureRatePerHour, hours) => Math.exp(-failureRatePerHour * hours);
exports.exponentialReliability = exponentialReliability;
const failureProbability = (failureRatePerHour, hours) => 1 - (0, exports.exponentialReliability)(failureRatePerHour, hours);
exports.failureProbability = failureProbability;
const mtbfFromFailureRate = (failureRatePerHour) => 1 / failureRatePerHour;
exports.mtbfFromFailureRate = mtbfFromFailureRate;
const failureRateFromMtbf = (mtbfHours) => 1 / mtbfHours;
exports.failureRateFromMtbf = failureRateFromMtbf;
const seriesReliability = (reliabilities) => reliabilities.reduce((p, r) => p * r, 1);
exports.seriesReliability = seriesReliability;
const parallelReliability = (reliabilities) => 1 - reliabilities.reduce((p, r) => p * (1 - r), 1);
exports.parallelReliability = parallelReliability;
const availability = (mtbfHours, mttrHours) => mtbfHours / (mtbfHours + mttrHours);
exports.availability = availability;
function kOfNReliability(componentReliability, k, n) {
    let sum = 0;
    for (let i = k; i <= n; i++)
        sum += combination(n, i) * componentReliability ** i * (1 - componentReliability) ** (n - i);
    return sum;
}
function combination(n, k) {
    if (k < 0 || k > n)
        return 0;
    let result = 1;
    for (let i = 1; i <= Math.min(k, n - k); i++)
        result = result * (n - i + 1) / i;
    return result;
}
//# sourceMappingURL=reliability.js.map