"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rotateY3 = exports.rotateX3 = exports.rotateZ3 = exports.reject3 = exports.project3 = exports.angle3 = exports.lerp3 = exports.negate3 = exports.normalize3 = exports.distance3 = exports.norm3 = exports.normSq3 = exports.cross3 = exports.dot3 = exports.scale3 = exports.sub3 = exports.add3 = exports.vec3 = void 0;
const vec3 = (x = 0, y = 0, z = 0) => [x, y, z];
exports.vec3 = vec3;
const add3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
exports.add3 = add3;
const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
exports.sub3 = sub3;
const scale3 = (v, k) => [v[0] * k, v[1] * k, v[2] * k];
exports.scale3 = scale3;
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
exports.dot3 = dot3;
const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
exports.cross3 = cross3;
const normSq3 = (v) => (0, exports.dot3)(v, v);
exports.normSq3 = normSq3;
const norm3 = (v) => Math.sqrt((0, exports.normSq3)(v));
exports.norm3 = norm3;
const distance3 = (a, b) => (0, exports.norm3)((0, exports.sub3)(a, b));
exports.distance3 = distance3;
const normalize3 = (v) => { const n = (0, exports.norm3)(v); return n === 0 ? [0, 0, 0] : (0, exports.scale3)(v, 1 / n); };
exports.normalize3 = normalize3;
const negate3 = (v) => [-v[0], -v[1], -v[2]];
exports.negate3 = negate3;
const lerp3 = (a, b, t) => (0, exports.add3)(a, (0, exports.scale3)((0, exports.sub3)(b, a), t));
exports.lerp3 = lerp3;
const angle3 = (a, b) => {
    const d = (0, exports.norm3)(a) * (0, exports.norm3)(b);
    return d === 0 ? 0 : Math.acos(Math.max(-1, Math.min(1, (0, exports.dot3)(a, b) / d)));
};
exports.angle3 = angle3;
const project3 = (a, onto) => {
    const d = (0, exports.normSq3)(onto);
    return d === 0 ? [0, 0, 0] : (0, exports.scale3)(onto, (0, exports.dot3)(a, onto) / d);
};
exports.project3 = project3;
const reject3 = (a, from) => (0, exports.sub3)(a, (0, exports.project3)(a, from));
exports.reject3 = reject3;
const rotateZ3 = (v, radians) => {
    const c = Math.cos(radians), s = Math.sin(radians);
    return [c * v[0] - s * v[1], s * v[0] + c * v[1], v[2]];
};
exports.rotateZ3 = rotateZ3;
const rotateX3 = (v, radians) => {
    const c = Math.cos(radians), s = Math.sin(radians);
    return [v[0], c * v[1] - s * v[2], s * v[1] + c * v[2]];
};
exports.rotateX3 = rotateX3;
const rotateY3 = (v, radians) => {
    const c = Math.cos(radians), s = Math.sin(radians);
    return [c * v[0] + s * v[2], v[1], -s * v[0] + c * v[2]];
};
exports.rotateY3 = rotateY3;
//# sourceMappingURL=vector.js.map