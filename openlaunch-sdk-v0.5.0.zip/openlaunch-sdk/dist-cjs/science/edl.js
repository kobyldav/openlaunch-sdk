"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.kineticEnergyJ = exports.ballisticCoefficientKgM2 = exports.decelerationG = exports.suttonGravesHeatFluxWm2 = exports.parachuteDiameterM = exports.parachuteAreaM2 = void 0;
const constants_js_1 = require("./constants.js");
const parachuteAreaM2 = (massKg, targetVelocityMps, densityKgM3, dragCoefficient, gravityMps2 = constants_js_1.PHYSICS.standardGravity) => 2 * massKg * gravityMps2 / (densityKgM3 * dragCoefficient * targetVelocityMps ** 2);
exports.parachuteAreaM2 = parachuteAreaM2;
const parachuteDiameterM = (areaM2) => 2 * Math.sqrt(areaM2 / Math.PI);
exports.parachuteDiameterM = parachuteDiameterM;
const suttonGravesHeatFluxWm2 = (densityKgM3, velocityMps, noseRadiusM, coefficient = 1.83e-4) => coefficient * Math.sqrt(densityKgM3 / noseRadiusM) * velocityMps ** 3;
exports.suttonGravesHeatFluxWm2 = suttonGravesHeatFluxWm2;
const decelerationG = (dragN, massKg, gravityMps2 = constants_js_1.PHYSICS.standardGravity) => dragN / massKg / gravityMps2;
exports.decelerationG = decelerationG;
const ballisticCoefficientKgM2 = (massKg, dragCoefficient, referenceAreaM2) => massKg / (dragCoefficient * referenceAreaM2);
exports.ballisticCoefficientKgM2 = ballisticCoefficientKgM2;
const kineticEnergyJ = (massKg, velocityMps) => 0.5 * massKg * velocityMps ** 2;
exports.kineticEnergyJ = kineticEnergyJ;
//# sourceMappingURL=edl.js.map