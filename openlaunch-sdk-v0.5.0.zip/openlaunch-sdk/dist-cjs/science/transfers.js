"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.interplanetaryPhaseAngle = exports.synodicPeriod = void 0;
exports.hohmannTransfer = hohmannTransfer;
exports.patchedConicDeparture = patchedConicDeparture;
exports.earthMarsHohmann = earthMarsHohmann;
exports.gravityAssistTurningAngle = gravityAssistTurningAngle;
exports.hyperbolicPeriapsisSpeed = hyperbolicPeriapsisSpeed;
const constants_js_1 = require("./constants.js");
const orbits_js_1 = require("./orbits.js");
function hohmannTransfer(r1M, r2M, mu) {
    const a = (r1M + r2M) / 2;
    const v1 = (0, orbits_js_1.circularVelocity)(r1M, mu), v2 = (0, orbits_js_1.circularVelocity)(r2M, mu);
    const vt1 = (0, orbits_js_1.visVivaVelocity)(r1M, a, mu), vt2 = (0, orbits_js_1.visVivaVelocity)(r2M, a, mu);
    const dv1 = Math.abs(vt1 - v1), dv2 = Math.abs(v2 - vt2);
    return { transferSemiMajorAxisM: a, transferTimeSeconds: Math.PI * Math.sqrt(a ** 3 / mu), deltaV1Mps: dv1, deltaV2Mps: dv2, totalDeltaVMps: dv1 + dv2 };
}
const synodicPeriod = (period1Seconds, period2Seconds) => 1 / Math.abs(1 / period1Seconds - 1 / period2Seconds);
exports.synodicPeriod = synodicPeriod;
const interplanetaryPhaseAngle = (r1M, r2M, mu = constants_js_1.BODIES.sun.mu) => {
    const transfer = hohmannTransfer(r1M, r2M, mu);
    const n2 = Math.sqrt(mu / r2M ** 3);
    return Math.PI - n2 * transfer.transferTimeSeconds;
};
exports.interplanetaryPhaseAngle = interplanetaryPhaseAngle;
function patchedConicDeparture(planetOrbitRadiusM, targetOrbitRadiusM, parkingRadiusM, planetMu, starMu = constants_js_1.BODIES.sun.mu) {
    const a = (planetOrbitRadiusM + targetOrbitRadiusM) / 2;
    const transferSpeed = (0, orbits_js_1.visVivaVelocity)(planetOrbitRadiusM, a, starMu);
    const planetSpeed = (0, orbits_js_1.circularVelocity)(planetOrbitRadiusM, starMu);
    const vinf = Math.abs(transferSpeed - planetSpeed);
    const parkingCircular = (0, orbits_js_1.circularVelocity)(parkingRadiusM, planetMu);
    const injection = Math.sqrt(vinf * vinf + 2 * planetMu / parkingRadiusM);
    return { heliocentricTransferSpeedMps: transferSpeed, planetOrbitalSpeedMps: planetSpeed, hyperbolicExcessMps: vinf, c3M2ps2: vinf * vinf, parkingOrbitCircularSpeedMps: parkingCircular, injectionSpeedMps: injection, injectionDeltaVMps: injection - parkingCircular };
}
function earthMarsHohmann() {
    const earthR = constants_js_1.BODIES.earth.semiMajorAxis, marsR = constants_js_1.BODIES.mars.semiMajorAxis;
    const transfer = hohmannTransfer(earthR, marsR, constants_js_1.BODIES.sun.mu);
    const a = transfer.transferSemiMajorAxisM;
    const earthTransferV = (0, orbits_js_1.visVivaVelocity)(earthR, a, constants_js_1.BODIES.sun.mu);
    const marsTransferV = (0, orbits_js_1.visVivaVelocity)(marsR, a, constants_js_1.BODIES.sun.mu);
    const earthV = (0, orbits_js_1.circularVelocity)(earthR, constants_js_1.BODIES.sun.mu), marsV = (0, orbits_js_1.circularVelocity)(marsR, constants_js_1.BODIES.sun.mu);
    return {
        transferTimeDays: transfer.transferTimeSeconds / 86400,
        synodicPeriodDays: (0, exports.synodicPeriod)(constants_js_1.BODIES.earth.orbitalPeriod, constants_js_1.BODIES.mars.orbitalPeriod) / 86400,
        departurePhaseAngleDeg: (0, exports.interplanetaryPhaseAngle)(earthR, marsR, constants_js_1.BODIES.sun.mu) * 180 / Math.PI,
        earthDepartureVInfinityMps: Math.abs(earthTransferV - earthV),
        earthDepartureC3M2ps2: (earthTransferV - earthV) ** 2,
        marsArrivalVInfinityMps: Math.abs(marsV - marsTransferV),
    };
}
function gravityAssistTurningAngle(mu, periapsisRadiusM, vInfinityMps) { const e = 1 + periapsisRadiusM * vInfinityMps ** 2 / mu; return 2 * Math.asin(1 / e); }
function hyperbolicPeriapsisSpeed(mu, periapsisRadiusM, vInfinityMps) { return Math.sqrt(vInfinityMps ** 2 + 2 * mu / periapsisRadiusM); }
//# sourceMappingURL=transfers.js.map